// import 'package:flutter/material.dart';
// import 'package:introduction_screen/introduction_screen.dart';
//
// class Intro extends StatelessWidget {
//   const Intro({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         child: PageViewModel(
//           title: "Title of introduction page",
//           body: "Welcome to the app! This is a description of how it works.",
//           image: const Center(
//             child: Icon(Icons.waving_hand, size: 50.0),
//           ),
//         ),,
//       )
//     );
//   }
// }
